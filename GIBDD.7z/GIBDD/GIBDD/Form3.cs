﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GIBDD
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e) //выход из приложения
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e) //переход на форму меню
        {
            Form2 NextForm = new Form2();
            NextForm.Show();
            Hide();
        }

        private void drivers2BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.drivers2BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.vDDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "vDDataSet.Drivers2". При необходимости она может быть перемещена или удалена.
            this.drivers2TableAdapter.Fill(this.vDDataSet.Drivers2);

        }
    }
}
