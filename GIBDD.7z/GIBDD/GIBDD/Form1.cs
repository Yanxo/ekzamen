﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GIBDD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "test") && (textBox2.Text == "test")) //проверка логина и пароля (удачный вход)
            {
                Form2 NextForm = new Form2();
                NextForm.Show();
                Hide();
            }
            else //проверка логина и пароля (неудачный вход)
            {
                MessageBox.Show("Неверный логин или пароль. Подождите минуту."); //вывод сообщения об ошибке
                textBox1.Text = ""; // очистка полей ввода
                textBox2.Text = ""; // очистка полей ввода
                DateTime now = DateTime.Now;
                while (DateTime.Now.Subtract(now).Minutes < 1)
                {
                    button1.Enabled = false;
                }
                button1.Enabled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close(); //кнопка выхода
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
