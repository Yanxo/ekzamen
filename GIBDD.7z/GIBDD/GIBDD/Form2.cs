﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GIBDD
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e) //переход на форму водители
        {
            Form3 NextForm = new Form3();
            NextForm.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e) //переход на форму удостоверения
        {
            Form4 NextForm = new Form4();
            NextForm.Show();
            Hide();
        }

        private void button3_Click(object sender, EventArgs e) //выход из приложения
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e) //переход на форму авторизациия
        {
            Form1 NextForm = new Form1();
            NextForm.Show();
            Hide();
        }
    }
}
