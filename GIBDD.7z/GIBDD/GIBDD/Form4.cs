﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GIBDD
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e) //выход из приложения
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e) //переход на форму меню
        {
            Form2 NextForm = new Form2();
            NextForm.Show();
            Hide();
        }

        private void licences1BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.licences1BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.vDDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "vDDataSet.licences1". При необходимости она может быть перемещена или удалена.
            this.licences1TableAdapter.Fill(this.vDDataSet.licences1);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Регистрационные номерные знаки Российской Федерации — специальный символический знак (№), изготовленный (нанесённый) на металлические (или из другого материала) пластины (формы) или транспортное средство (ТС), используемое для учёта автомобилей, мотоциклов, грузовой, специальной, строительной техники и вооружения, прицепов. Устанавливаются на передней и задней частях техники(на прицепы и мотоциклы — только сзади). Комбинации на стандартных номерных знаках строятся по принципу — 3 буквы, 3 цифры. Буквы означают серию номерного знака, а цифры — номер. ГОСТом для использования на знаках разрешены 12 букв кириллицы, имеющие графические аналоги в латинском алфавите — А, В, Е, К, М, Н, О, Р, С, Т, У и Х. В правой части номерного знака имеется секция, в которой размещены: в нижней части — флаг РФ и буквенный код RUS, а в верхней — код субъекта РФ, где был зарегистрирован автомобиль. Буквы и цифры кода региона по размеру шрифта меньше, чем основные цифры.");
        }
    }
}
